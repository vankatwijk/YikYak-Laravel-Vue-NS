# Nativescript Social Network for people in Sports

```
#Pre-requirements
-android studio with android 9.0 sdk(this is needed for testing and building)
-node with npm
-nativescript (npm install -g nativescript)
-vuejs (npm install -g vue)
```

```
#installation
-npm install
```

### Description:
this is a social media application like linkedin for people in sports, the difference is being able to follow a tag from a person and not the person itself, allowing you to filter the information in your feed.

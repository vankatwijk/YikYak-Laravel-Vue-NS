module.exports = require("nativescript-vue/dist/hooks/before-watch.js");

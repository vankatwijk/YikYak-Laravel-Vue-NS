<template>
    <Page class="page">

        <ActionBar title="" class="action-bar header"  style='background-color:black;'>
            <StackLayout orientation="horizontal" height="38" alignItems="left"
                class="actionBarContainer">
                <StackLayout class="HLeft" style="margin-top:10;" @tap="toggleDrawer()">
                    <Label :text="drawerToggle ? drawer2: drawer1" style="font-size:27;color:#fff;"
                        class="font-awesome" />
                </StackLayout>

                <StackLayout class="HMid" alignItems="left">
                </StackLayout>

                <StackLayout class="HRight">

                </StackLayout>
            </StackLayout>
        </ActionBar>

        <RadSideDrawer ref="drawer" @drawerOpened="onDrawerOpened()"
            @drawerClosed="onDrawerClosed()">
            <StackLayout ~drawerContent backgroundColor="#eee">
                <StackLayout height="80%"></StackLayout>
                <StackLayout class="">
                    <Label text="  Log out" paddingLeft="30%" color="black"
                        class="drawerItemText font-awesome" margin="10" @tap="logout"/>
                </StackLayout>
            </StackLayout>

            <StackLayout ~mainContent>

                <DockLayout>

                    <StackLayout dock="top" height="90%" width="100%" style="">

                        <RadListView ref="listView"
                            for="item in homePosts"
                            pullToRefresh="true"
                            :key="index" height="100%"
                            backgroundColor="#E8E8E8" separatorColor="transparent"
                            id="listView"
                            @pullToRefreshInitiated="onPullToRefreshInitiated">

                            <v-template>

                                <StackLayout paddingTop="5" backgroundColor="#E8E8E8">
                                    <StackLayout class="postContainer">
                                        <StackLayout orientation="horizontal"
                                            padding="10">
                                            <Image :src="APIURL+'/uploads/avatars/'+item.authorImg"
                                                stretch="aspectFill" class="postImageSmall" />
                                            <StackLayout>
                                                <Label :text="item.autorName"
                                                    class="postAuthotName" />
                                                <Label :text="item.date"
                                                    class="postDateSmall" />
                                            </StackLayout>
                                        </StackLayout>
                                        <HtmlView marginLeft="10" marginRight="10"
                                            class="postTitle" :html="item.title" />
                                        <Image :src="item.postImg" marginTop="10" />
                                        <StackLayout orientation="horizontal"
                                            padding="10" marginLeft="10%">
                                            <Label text=" " style="font-size:18;margin-top:-1;"
                                                :color="item.color" class="fa fa-hand-spock-o " />
                                            <Label :text="item.likes" style="font-size:12;color:#1aa3ff;" />
                                        </StackLayout>
                                    </StackLayout>
                                </StackLayout>

                            </v-template>
                        </RadListView>

                    </StackLayout>


                    <StackLayout dock="bottom" height="10%" style="border-color:#E4E4E4;border-width:1;background:#fff;">
                          <GridLayout columns="*, *" verticalAlignment="top">
                            <StackLayout col="0" class="navItem" @tap="homeTap()">
                                <Label text="" android:class="notificationAndroid"
                                    ios:class="notification" opacity="0" />
                                <Label text="" :color="mainColor"
                                    android:style="font-size:18;margin-top:-15"
                                    ios:style="font-size:30;margin-top:-15"
                                    class="font-awesome" />
                                <Label text="Home" style="font-size:10;" :color="mainColor" />
                            </StackLayout>
                            <StackLayout col="1" class="navItem" @tap="postTap()">
                                <Label text="df" android:class="notificationAndroid"
                                    ios:class="notification" opacity="0" />
                                <Label text="" android:style="font-size:18;margin-top:-15"
                                    ios:style="font-size:30;margin-top:-15"
                                    class="font-awesome" />
                                <Label text="Post" style="font-size:10;" />
                            </StackLayout>

                        </GridLayout>
                    </StackLayout>

                </DockLayout>

            </StackLayout>
        </RadSideDrawer>

    </page>
</template>
<script>
    import Home from "./Home";
    import Login from "./Login";
    import Post from "./Post";

    const httpModule = require("http");
    const appSettings = require("tns-core-modules/application-settings");

    export default {
        computed: {},
        watch: {},
        created() {
            setTimeout(() => {
                this.getPosts();
            }, 500);
        },
        data() {
            return {
                searchValue: '',
                drawerToggle: false,
                drawer1: "",
                drawer2: "",
                mainColor: "#1aa3ff",
                APIURL: "",
                homePosts: []
            };
        },
        methods: {
            onStart(){

            },
            getPosts(){
                var userToken = appSettings.getString('userToken',0);
                var appURL = appSettings.getString('appURL',0);
                this.APIURL = appURL;



                httpModule.request({
                    url: appURL+'/api/home',//"http://192.168.0.83:8000/api/home",
                    method: "Get",
                    headers: { 
                        "Content-Type": "application/json" ,
                        "Authorization": "Bearer "+userToken
                    }
                }).then(response => {
                    var result =response.content.toJSON();
                    //alert('ll');
                    this.homePosts = result.posts;
                    console.log(this.homePosts);
                    console.log("ID FIRST ITEM")
                    console.log(typeof this.homePosts[0].id);
                    //alert(this.homePosts);

                

                }, error => {
                    console.error(error);
                });

            },
            onPullToRefreshInitiated({ object }) {
                this.$nextTick(() => {

                    this.getPosts();

                    object.notifyPullToRefreshFinished();
                });
            },
            onDrawerClosed() {
                this.drawerToggle = false;
            },
            onDrawerOpened() {
                this.drawerToggle = true;
            },
            toggleDrawer() {
                this.$refs.drawer.nativeView.toggleDrawerState();
            },
            homeTap() {},
            profileTap() {
                this.$navigateTo(Profile, {
                    animated: false,
                    clearHistory: true
                });
            },
            postTap() {
                this.$navigateTo(Post, {
                    animated: false,
                    clearHistory: true
                });
            },
            conversationsTap() {
                this.$navigateTo(Convs, {
                    animated: false,
                    clearHistory: true
                });
            },
            logout() {
                this.$navigateTo(Login, {
                    clearHistory: true
                });
            },
            searchSubmited(){

                this.$navigateTo(Search, {
                    animated: {
                        name:'fade',
                        duration: 200
                    },
                    clearHistory: true,
                    props: {
                        searchValue: this.searchValue
                    }
                });

            },



            notificationsTap() {

                var userToken = appSettings.remove('userToken');
                var appURL = appSettings.remove('appURL');
                this.$navigateTo(Notification, {
                    clearHistory: true
                });
            },
            showDetails() {}
        }
    };
</script>

<style scoped>

</style>
import Login from "../components/Login";
import Home from "../components/Home";

const routes = {
    login: Login,
    home: Home
}
export default routes;